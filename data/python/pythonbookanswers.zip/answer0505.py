from random import random

print( "A random integer between 1 and 10 is", 
    1 + int( random() * 10 ) )
