pi = 3.14159
radius = 12
print( "The surface area of a circle with radius", 
    radius, "is", pi * radius * radius )
