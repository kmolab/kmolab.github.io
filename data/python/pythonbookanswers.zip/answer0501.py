s = input( "Enter a string: " )
print( "You entered", len( s ), "characters" )
