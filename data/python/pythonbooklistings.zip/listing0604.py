x = 5
if x == 5: 
    print( "x equals 5" )
if x > 4: 
    print( "x is greater than 4" )
if  x >= 5:
    print( "x is greater than or equal to 5" )
if x < 6: 
    print( "x is less than 6" ) 
if x <= 5:
    print( "x is less than or equal to 5" )
if x != 6 :
    print( "x does not equal 6" )