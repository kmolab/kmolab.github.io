fp = open( "pc_rose.txt" )
print( fp.read() )
fp.close()