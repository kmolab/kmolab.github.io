fruitset = { "apple", "banana", "cherry", "durian", "mango" }
print( fruitset )
fruitset.add( "apple" )
fruitset.add( "elderberry" )
print( fruitset )
fruitset.update( ["apple","apple","apple","strawberry",
    "strawberry","apple","mango"] )
print( fruitset )