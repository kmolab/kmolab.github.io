wordlist = ["apple","durian","banana","durian","apple","cherry",
    "cherry","mango","apple","apple","cherry","durian","banana",
    "apple","apple","apple","apple","banana","apple"]