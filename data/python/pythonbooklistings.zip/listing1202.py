fruitlist = ["apple", "banana"]
fruitlist += "cherry"
print( fruitlist )

fruitlist = ["apple", "banana"]
fruitlist += ["cherry"]
print( fruitlist )