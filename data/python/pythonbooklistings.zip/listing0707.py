for fruit in ( "apple", "orange", "strawberry" ):
    print( fruit )
else:
    print( "The loop ends, fruit is now", fruit )
print( "Done" )