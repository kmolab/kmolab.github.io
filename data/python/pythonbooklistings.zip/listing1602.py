with open( "pc_rose.txt" ) as fp:
    buffer = fp.read()
print( buffer )