long = "I'm fed up with being treated like sheep. What's the \
point of going abroad if you're just another tourist carted \
around in buses surrounded by sweaty mindless oafs from \
Kettering and Coventry in their cloth caps and their cardigans \
and their transistor radios and their Sunday Mirrors, \
complaining about the tea - 'Oh they don't make it properly \
here, do they, not like at home' - and stopping at Majorcan \
bodegas selling fish and chips and Watney's Red Barrel and \
calamaris and two veg and sitting in their cotton frocks \
squirting Timothy White's suncream all over their puffy raw \
swollen purulent flesh 'cos they 'overdid it on the first day.'"
print( long )