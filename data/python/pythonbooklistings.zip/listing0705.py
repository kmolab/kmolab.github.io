fruit = "banana"
for letter in fruit:
    print( letter )
    if letter == "n":
        fruit = "orange"
print( "Done" )