# comment: insert your code here.
# BTW: Have you noticed that everything right of the hash mark 
print( "Something..." ) # is ignored by your python interpreter?
print( "and something else.." ) # Use this to comment your code!
"""Another way of commenting on your code is via triple quotes 
-- these can be distributed over multiple """ # lines
'''which can also be done with single quotes''' # but be careful 
# with there being quotes IN your comments when you use this 
# multi-line method
print( "Done." )