long = """And being herded into endless Hotel Miramars and 
Bellevueses and Continentales with their modern international
luxury roomettes and draught Red Barrel and swimming pools full
of fat German businessmen pretending they're acrobats forming 
pyramids and frightening the children and barging into queues 
and if you're not at your table spot on seven you miss the bowl 
of Campbell's Cream of Mushroom soup, the first item on the menu 
of International Cuisine, and every Thursday night the hotel has 
a bloody cabaret in the bar, featuring a tiny emaciated dago with
nine-inch hips and some bloated fat tart with her hair brylcreemed 
down and a big arse presenting Flamenco for Foreigners."""
print( long )