numlist = [ 100, 101, 0, "103", 104 ]

i1 = int( input( "Give an index: " ) )
print( "100 /", numlist[i1], "=", 100 / numlist[i1] )