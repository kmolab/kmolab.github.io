i = 0
while i < 5:
    print( i )
    i += 1
else:
    print( "The loop ends, i is now", i )
print( "Done" )