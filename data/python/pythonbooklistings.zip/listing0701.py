num = 1
while num <= 5:
    print( num )
    num += 1
print( "Done" )