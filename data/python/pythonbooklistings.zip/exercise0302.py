print( "A message" ).
print( "A message' )
print( 'A messagef"' )