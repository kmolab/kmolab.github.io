allthings = {"Socrates", "Plato", "Eratosthenes", "Zeus", "Hera", 
    "Athens", "Acropolis", "Cat", "Dog"}
men = {"Socrates", "Plato", "Eratosthenes"}
mortalthings = {"Socrates", "Plato", "Eratosthenes", "Cat", "Dog"}