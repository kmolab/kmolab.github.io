hello = "Hi!"
bye = "Goodbye!"

for i in range( 3 ):
    for j in range( 2 ):
        afternoon = "Good afternoon"
        print( bye )
    print( j )
    print( hello )
    print( afternoon )

print( i )
print( j )
print( afternoon )